/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imageapp;

import static imageapp.functions.isEmpty;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Slider;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;



/**
 *
 * @author joao_
 */
public class FXMLDocumentController implements Initializable {

    
    private Stage stage;
    
    @FXML
    MenuItem loadBtn, exitBtb;
    
    @FXML
    Slider brightSlider, hueSlider, contrastSlider, satSlider;
    
    @FXML
    Label errorLabel;
    @FXML
    ImageView originalImg, myImage;
    
    Image image1,image2,orig;
    
   
    
   
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
      
        // TODO
    } 

    @FXML
    private void handleLoad(ActionEvent event) {
        
        FileChooser fileChooser = new FileChooser();
        
        //Set extension filter
        FileChooser.ExtensionFilter extFilterJPG = new FileChooser.ExtensionFilter("JPG files (*.jpg)", "*.JPG");
        FileChooser.ExtensionFilter extFilterPNG = new FileChooser.ExtensionFilter("PNG files (*.png)", "*.PNG");
        fileChooser.getExtensionFilters().addAll(extFilterJPG, extFilterPNG);
        
        //Show open file dialog
        File file = fileChooser.showOpenDialog(null);
        
        try {
                BufferedImage bufferedImage = ImageIO.read(file);
                Image image = SwingFXUtils.toFXImage(bufferedImage, null);
                originalImg.setImage(image);
                myImage.setImage(image);
                image1=image;
                image2=image;
                myImage.setVisible(false);
            } catch (IOException ex) {
                //Logger.getLogger(JavaFXPixel.class.getName()).log(Level.SEVERE, null, ex);
            }

    }

    @FXML
    private void handleExit(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void setBright(ActionEvent event) {
        if (!isEmpty(originalImg)) {
            
            image2 = originalImg.getImage();
            double value = brightSlider.getValue() + 1.00;
            String p = value + "f";
            BufferedImage img = SwingFXUtils.fromFXImage(image2, null);
            float scaleFactor = Float.valueOf(p);
            RescaleOp rescaleOp = new RescaleOp(scaleFactor, 0, null);
            img = rescaleOp.filter(img, null);
            Image s = SwingFXUtils.toFXImage(img, null);
            myImage.setImage(s);
            myImage.setVisible(true);
        }
        else{
            errorLabel.setText("Error: No image available to transform!");
        }
    }

    @FXML
    private void setContrast(ActionEvent event) {
         if (!isEmpty(originalImg)) {
            
            double a = contrastSlider.getValue();
            ColorAdjust blackout = new ColorAdjust();
            blackout.setContrast(a);
            myImage.setEffect(blackout);
            myImage.setVisible(true);
        }
        else {
            errorLabel.setText("Error: No image available to transform!");
        }
    }

    @FXML
    private void setSat(ActionEvent event) {
        if (!isEmpty(originalImg)){
           
            double a = satSlider.getValue();
            ColorAdjust blackout = new ColorAdjust();
            blackout.setSaturation(a);
            myImage.setEffect(blackout);
            myImage.setVisible(true);
        }
        else {
            errorLabel.setText("Error: No image available to transform!");
        }
    }

    @FXML
    private void setHue(ActionEvent event) {
        if (!isEmpty(originalImg)) {
            
            double a = hueSlider.getValue();
            ColorAdjust blackout = new ColorAdjust();
            blackout.setHue(a);
            myImage.setEffect(blackout);
            myImage.setVisible(true);
        }
        else {
            errorLabel.setText("Error: No image available to transform!");
        }
    }

    @FXML
    private void setGray(ActionEvent event) {
        if (!isEmpty(originalImg)) {


            if (isEmpty(myImage)) {
                image2 = image1;
            } else {
                image2 = myImage.getImage();
            }
            errorLabel.setText("");
            BufferedImage img = SwingFXUtils.fromFXImage(image2, null);
            int width = img.getWidth();
            int height = img.getHeight();

            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    int p = img.getRGB(j, i);
                    int a = (p >> 24) & 0xff;
                    int r = (p >> 16) & 0xff;
                    int g = (p >> 8) & 0xff;
                    int b = p & 0xff;
                    int avg = (r + g + b) / 3;
                    p = (a << 24) | (avg << 16) | (avg << 8) | avg;
                    img.setRGB(j, i, p);
                }
            }
            Image s = SwingFXUtils.toFXImage(img, null);
            myImage.setImage(s);
            myImage.setVisible(true);
        }
        else {
            errorLabel.setText("Error: No image available to transform!");
        }
    }

    @FXML
    private void setNeg(ActionEvent event) {
        if (!isEmpty(originalImg)) {
            if (isEmpty(myImage)) {
                image2 = image1;
            } else {
                image2 = myImage.getImage();
            }
            errorLabel.setText("");
            BufferedImage img = SwingFXUtils.fromFXImage(image2, null);
            int width = img.getWidth();
            int height = img.getHeight();
            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    int p = img.getRGB(j, i);
                    int a = (p >> 24) & 0xff;
                    int r = (p >> 16) & 0xff;
                    int g = (p >> 8) & 0xff;
                    int b = p & 0xff;
                    r = 255 - r;
                    g = 255 - g;
                    b = 255 - b;
                    p = (a << 24) | (r << 16) | (g << 8) | b;
                    img.setRGB(j, i, p);
                }
            }
            Image s = SwingFXUtils.toFXImage(img, null);
            myImage.setImage(s);
            myImage.setVisible(true);
        }
        else {
            errorLabel.setText("Error: No image available to transform!");
        }
    }

    @FXML
    private void setHist(ActionEvent event) {
        if (!isEmpty(myImage)) {
            
            image2 = myImage.getImage();
            BufferedImage img = SwingFXUtils.fromFXImage(image2, null);
            Histogram histogram = new Histogram(img);
        }
        else{
            errorLabel.setText("Error: No image available to show Histogram!");
        }
    }

    @FXML
    private void setBlur(ActionEvent event) {
        if (!isEmpty(originalImg)) {
            if (isEmpty(myImage)) {
                image2 = image1;
            } else {
                image2 = myImage.getImage();
            }
            
            Image a = Blur.main(image2);
            myImage.setImage(a);
            myImage.setVisible(true);
        }
        else{
            errorLabel.setText("Error: No image available to transform!");
        }
    }

    @FXML
    private void setEdge(ActionEvent event) {
        if (!isEmpty(originalImg)) {
            
            image2 = image1;
            BufferedImage img = SwingFXUtils.fromFXImage(image2, null);
            Edge edge = new Edge();
            edge.setSourceImage(img);
            edge.process();
            BufferedImage img2 = edge.getEdgesImage();
            Image s = SwingFXUtils.toFXImage(img2, null);
            myImage.setImage(s);
            myImage.setVisible(true);
        }
        else{
            errorLabel.setText("Error: No image available to transform!");
        }
    }
    public static boolean isEmpty(ImageView imageView) {
        Image image = imageView.getImage();
        return image == null || image.isError();
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (!isEmpty(myImage)){
            
            Image ff = myImage.getImage();
            JFileChooser chooser = new JFileChooser();
            FileNameExtensionFilter filter = new FileNameExtensionFilter("PNG Files", "PNG");
            chooser.setFileFilter(filter);
            chooser.setCurrentDirectory(new File("/home/"));
            int retrival = chooser.showSaveDialog(null);
            if (retrival == JFileChooser.APPROVE_OPTION) {
                try {
                    BufferedImage img = SwingFXUtils.fromFXImage(ff, null);
                    ImageIO.write(img, "png", chooser.getSelectedFile());

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        else {
            errorLabel.setText("Error: No image available to save!");
        }
    }

    @FXML
    private void handleClear(ActionEvent event) {
    }

    @FXML
    private void handleReset(ActionEvent event) {
    }

 }